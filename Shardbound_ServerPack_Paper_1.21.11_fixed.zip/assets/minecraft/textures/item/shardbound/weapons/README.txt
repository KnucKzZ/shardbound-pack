Place apprentice_staff.png here after exporting or painting your texture.
Recommended start: 32x32 PNG.
