Shardbound Dark UI v2

Updated in this version
- Tighter inventory frame and slot alignment
- Matching large chest/menu styling
- Custom hotbar and selected slot highlight
- Offhand slot plates
- Custom hearts, armor icons, hunger icons, and XP bar

Java install
1. Keep this ZIP zipped.
2. Host it at a direct URL.
3. Put that direct URL in server.properties under resource-pack=
4. Restart the server and reconnect.
5. If an older version is cached, delete %appdata%/.minecraft/server-resource-packs and reconnect.

This pack is for Java Edition. Bedrock players need a separate Bedrock-format pack.


v3 fix:
- Removed the thick black XP/stamina-looking bar under the HUD.
- Replaced it with a slim transparent crystal line.
