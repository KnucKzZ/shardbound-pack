Shardbound Dark UI Pack

What this pack changes
- Player inventory screen
- Large chest / menu style (generic 54-slot containers)

Install for Java players
1. Upload this ZIP somewhere direct-downloadable.
2. Put the URL in server.properties as resource-pack=
3. Restart the server.

Bedrock players via Geyser
- Java resource packs do not automatically convert to Bedrock.
- To support Bedrock players too, place a Bedrock-format pack in your Geyser packs folder.

Notes
- This pack is built for Java 1.21 pack format 34.
- If you move to a later 1.21.x version and Minecraft marks it as older, the textures may still work, but the pack.mcmeta may need an updated pack_format.
